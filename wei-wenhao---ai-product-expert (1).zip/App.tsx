
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Github, 
  Linkedin, 
  Mail, 
  Phone, 
  ArrowRight, 
  ChevronDown, 
  Terminal, 
  Cpu, 
  BrainCircuit, 
  MessageSquare,
  Share2,
  ExternalLink,
  Download,
  Copy,
  Check,
  X
} from 'lucide-react';

// --- Types ---

interface NavItem {
  id: string;
  label: string;
}

// --- Components ---

const FluidBackground: React.FC = () => {
  return (
    <div className="fluid-mesh">
      <div className="blob bg-purple-600 top-[-10%] left-[-10%]"></div>
      <div className="blob bg-blue-600 top-[20%] right-[-10%]"></div>
      <div className="blob bg-green-600 bottom-[-10%] left-[20%]"></div>
      <div className="blob bg-pink-600 bottom-[20%] right-[10%]"></div>
    </div>
  );
};

const Typewriter: React.FC<{ phrases: string[] }> = ({ phrases }) => {
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(150);

  useEffect(() => {
    const handleTyping = () => {
      const fullText = phrases[currentPhraseIndex];
      
      if (!isDeleting) {
        setCurrentText(fullText.substring(0, currentText.length + 1));
        setTypingSpeed(100);

        if (currentText === fullText) {
          setIsDeleting(true);
          setTypingSpeed(2000); 
        }
      } else {
        setCurrentText(fullText.substring(0, currentText.length - 1));
        setTypingSpeed(50);

        if (currentText === '') {
          setIsDeleting(false);
          setCurrentPhraseIndex((prev) => (prev + 1) % phrases.length);
          setTypingSpeed(500);
        }
      }
    };

    const timer = setTimeout(handleTyping, typingSpeed);
    return () => clearTimeout(timer);
  }, [currentText, isDeleting, currentPhraseIndex, phrases, typingSpeed]);

  return (
    <span className="font-mono text-cyan-400">
      {currentText}
      <span className="animate-pulse">|</span>
    </span>
  );
};

const Section: React.FC<{ id: string; children: React.ReactNode; className?: string }> = ({ id, children, className = "" }) => (
  <section id={id} className={`min-height-screen py-20 px-6 max-w-5xl mx-auto ${className}`}>
    {children}
  </section>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems: NavItem[] = [
    { id: 'home', label: '主页' },
    { id: 'about', label: '关于' },
    { id: 'skills', label: '核心能力' },
    { id: 'contact', label: '联系' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveTab(id);
      setIsMenuOpen(false);
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  /**
   * 功能：将当前应用的所有逻辑封装进一个独立的 HTML 文件并触发下载
   */
  const exportToSingleHTML = async () => {
    const response = await fetch(window.location.href);
    const htmlTemplate = await response.text();
    
    // 我们需要把 index.tsx 的内容也获取并内联
    // 由于这里是演示，我们模拟内联逻辑。在生产环境中，这通常通过打包工具完成
    // 在这里，我们将触发浏览器自带的 "另存为" 或者生成一个说明文档
    const blob = new Blob([htmlTemplate], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `卫文昊_AI产品专家_个人网站.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative z-10 min-h-screen">
      <FluidBackground />
      <div className="scanlines"></div>

      {/* Navigation */}
      <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/80 backdrop-blur-md py-4' : 'bg-transparent py-8'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-xl font-bold tracking-tighter"
          >
            卫文昊 <span className="text-xs text-cyan-500 font-mono">/AI PRODUCT</span>
          </motion.div>
          
          <div className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className={`text-sm font-mono tracking-widest transition-colors ${activeTab === item.id ? 'text-white underline underline-offset-8' : 'text-gray-400 hover:text-white'}`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <button 
            onClick={() => setIsShareOpen(true)}
            className="p-2 text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <Share2 size={20} />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <Section id="home" className="flex flex-col items-center justify-center min-h-screen text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative mb-8"
        >
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500 to-purple-600 rounded-full blur-2xl opacity-40 animate-pulse"></div>
          <img 
            src="https://picsum.photos/seed/handsome-guy-ai/400/400" 
            alt="卫文昊" 
            className="w-48 h-48 md:w-64 md:h-64 rounded-full border-2 border-white/20 object-cover relative z-10 filter grayscale contrast-125 brightness-90 hover:grayscale-0 transition-all duration-700"
          />
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-5xl md:text-8xl font-black mb-4 tracking-tighter"
        >
          卫文昊
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-xl md:text-3xl font-light text-gray-300 flex flex-col md:flex-row items-center justify-center gap-2"
        >
          <span>致力于</span>
          <Typewriter phrases={[
            "重塑人机交互的新范式",
            "探索LLM在大规模场景下的落地",
            "打造有温度的AI原生产品",
            "用算法定义数字世界的未来"
          ]} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="mt-12"
        >
          <button 
            onClick={() => scrollTo('about')}
            className="flex flex-col items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <span className="text-xs font-mono uppercase tracking-[0.2em]">向下滚动</span>
            <ChevronDown className="animate-bounce" size={24} />
          </button>
        </motion.div>
      </Section>

      {/* About Section */}
      <Section id="about">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 flex items-center gap-4">
              <span className="h-1 w-12 bg-cyan-500 rounded-full"></span>
              关于我
            </h2>
            <div className="space-y-6 text-lg text-gray-300 font-light leading-relaxed">
              <p>
                我是 <span className="text-white font-medium">卫文昊</span>，一名专注于AI赛道的产品专家。在通用人工智能（AGI）浪潮中，我始终寻找技术边界与用户需求的完美平衡。
              </p>
              <p>
                拥有深厚的算法认知与敏锐的产品洞察，曾主导过多个百万级DAU的AI原生应用从0到1的落地。我认为，优秀的AI产品不应只是冷冰冰的代码，而应当是理解人性、能与用户共情的数字生命。
              </p>
              <div className="flex gap-4 pt-4">
                <div className="px-4 py-2 border border-white/10 bg-white/5 rounded-lg text-sm font-mono">
                  # LLM Strategy
                </div>
                <div className="px-4 py-2 border border-white/10 bg-white/5 rounded-lg text-sm font-mono">
                  # AI Native UX
                </div>
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative p-8 border border-white/10 bg-white/5 backdrop-blur-sm rounded-3xl overflow-hidden"
          >
             <div className="absolute -top-4 -left-4 w-12 h-12 border-t-2 border-l-2 border-cyan-500"></div>
             <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-2 border-r-2 border-purple-500"></div>
             
             <div className="space-y-4">
               <div className="flex items-center gap-4">
                 <Terminal className="text-cyan-500" size={20} />
                 <span className="text-sm font-mono text-gray-400">STATUS: ACTIVE_DEVELOPMENT</span>
               </div>
               <div className="text-sm font-mono leading-tight whitespace-pre">
                 <span className="text-green-400">➜</span> <span className="text-blue-400">~/profile</span> cat intro.sh<br/>
                 <span className="text-gray-500"># 输出个人标签</span><br/>
                 echo "1. 多模态交互专家"<br/>
                 echo "2. 产品架构师"<br/>
                 echo "3. 连续创业者"<br/>
                 <span className="text-green-400">➜</span> <span className="text-blue-400">~/profile</span> _
               </div>
             </div>
          </motion.div>
        </div>
      </Section>

      {/* Skills Section */}
      <Section id="skills">
        <h2 className="text-3xl md:text-5xl font-bold mb-16 text-center">核心能力矩阵</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <BrainCircuit className="text-purple-500" size={32} />,
              title: "AI 架构设计",
              desc: "深度理解 Transformer 架构及各类主流大模型的能力边界，精准进行模型选型与 RAG 架构设计。"
            },
            {
              icon: <MessageSquare className="text-cyan-500" size={32} />,
              title: "Prompt 工程",
              desc: "精通复杂指令集设计，擅长通过思维链（CoT）与少样本学习（Few-shot）提升垂直场景下的输出质量。"
            },
            {
              icon: <Cpu className="text-green-500" size={32} />,
              title: "产品化落地",
              desc: "将技术逻辑转化为交互体验，解决 AI 幻觉带来的挑战，确保产品具备极高的商业化价值。"
            }
          ].map((skill, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="group p-8 border border-white/10 bg-white/5 rounded-3xl hover:bg-white/10 transition-all duration-300"
            >
              <div className="mb-6 p-4 bg-black/40 rounded-2xl w-fit group-hover:scale-110 transition-transform">
                {skill.icon}
              </div>
              <h3 className="text-xl font-bold mb-4">{skill.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{skill.desc}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Contact Section */}
      <Section id="contact" className="pb-32">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-6xl font-black mb-8 tracking-tighter">
            与其讨论未来 <br/>不如共同<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">创造它</span>
          </h2>
          
          <div className="grid gap-4 md:grid-cols-2">
            <a 
              href="tel:13913835055"
              className="flex items-center justify-between px-8 py-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-cyan-500/50 transition-all"
            >
              <div className="flex items-center gap-4">
                <Phone className="text-cyan-400" size={24} />
                <div className="text-left">
                  <div className="text-xs text-gray-500 font-mono">CALL ME</div>
                  <div className="font-bold">13913835055</div>
                </div>
              </div>
              <ArrowRight size={18} className="text-gray-600" />
            </a>
            
            <a 
              href="mailto:wei.wh@ai.com"
              className="flex items-center justify-between px-8 py-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-purple-500/50 transition-all"
            >
              <div className="flex items-center gap-4">
                <Mail className="text-purple-400" size={24} />
                <div className="text-left">
                  <div className="text-xs text-gray-500 font-mono">EMAIL ME</div>
                  <div className="font-bold">wei.wh@ai.com</div>
                </div>
              </div>
              <ArrowRight size={18} className="text-gray-600" />
            </a>
          </div>
        </div>
      </Section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5 text-center px-6 mb-[env(safe-area-inset-bottom)]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500 font-mono">
            &copy; {new Date().getFullYear()} WEI WENHAO. DESIGNED FOR THE AI AGE.
          </p>
          <div className="flex gap-6">
            <span onClick={exportToSingleHTML} className="text-xs text-gray-500 font-mono hover:text-white cursor-pointer transition-colors flex items-center gap-1">
              离线导出 <Download size={12}/>
            </span>
            <span className="text-xs text-gray-500 font-mono hover:text-white cursor-pointer transition-colors flex items-center gap-1">
              作品集 <ExternalLink size={12}/>
            </span>
          </div>
        </div>
      </footer>

      {/* Floating Share Menu */}
      <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end gap-4">
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.8 }}
              className="flex flex-col gap-3 mb-2"
            >
              <button 
                onClick={exportToSingleHTML}
                className="flex items-center gap-3 bg-white text-black px-4 py-3 rounded-2xl shadow-xl hover:bg-cyan-50 transition-colors group"
              >
                <span className="text-xs font-bold uppercase tracking-widest">导出为 HTML 文件</span>
                <Download size={18} className="group-hover:translate-y-0.5 transition-transform" />
              </button>
              
              <button 
                onClick={() => { setIsShareOpen(true); setIsMenuOpen(false); }}
                className="flex items-center gap-3 bg-cyan-600 text-white px-4 py-3 rounded-2xl shadow-xl hover:bg-cyan-500 transition-colors group"
              >
                <span className="text-xs font-bold uppercase tracking-widest">生成分享二维码</span>
                <Share2 size={18} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className={`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all duration-500 ${isMenuOpen ? 'bg-white text-black rotate-90' : 'bg-cyan-500 text-white'}`}
        >
          {isMenuOpen ? <X size={24} /> : <Share2 size={24} />}
        </motion.button>
      </div>

      {/* Share Modal */}
      <AnimatePresence>
        {isShareOpen && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-zinc-900 border border-white/10 p-8 rounded-[2rem] max-w-sm w-full shadow-2xl overflow-hidden"
            >
              <button 
                onClick={() => setIsShareOpen(false)}
                className="absolute top-4 right-4 p-2 text-gray-500 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>

              <div className="text-center">
                <div className="inline-block p-4 bg-white rounded-3xl mb-6">
                  {/* 二维码占位 - 实际开发中可接入 qrcode.react */}
                  <div className="w-40 h-40 bg-zinc-100 flex items-center justify-center overflow-hidden">
                    <img 
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.href)}&bgcolor=ffffff&color=000000`} 
                      alt="QR Code" 
                      className="w-full h-full"
                    />
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-2">分享我的名片</h3>
                <p className="text-sm text-gray-400 mb-8 font-light">
                  扫描上方二维码或点击下方按钮复制链接分享到微信、飞书或朋友圈。
                </p>

                <div className="flex gap-4">
                  <button 
                    onClick={copyLink}
                    className="flex-1 flex items-center justify-center gap-2 py-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all font-mono text-sm"
                  >
                    {isCopied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                    {isCopied ? '已复制' : '复制链接'}
                  </button>
                  <button 
                    onClick={exportToSingleHTML}
                    className="flex-1 flex items-center justify-center gap-2 py-4 bg-cyan-600 rounded-2xl hover:bg-cyan-500 transition-all font-mono text-sm"
                  >
                    <Download size={18} />
                    下载文件
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
